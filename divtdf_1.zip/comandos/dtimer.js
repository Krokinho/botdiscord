module.exports = {
  run: async (client, message, [ time ]) => {
    await message.delete()
    const messages = await message.channel.fetchMessages({ limit: 100 })
    const userMessages = messages.filter((m) => m.author === message.author && m.deletable)
    if (userMessages === 0) return message.reply('<a:erradoHXZ:727856180663287898> Não encontrei nenhuma mensagem recente para apagar.')
    const target = userMessages.first()
    if (!target.deletable) return message.reply('<a:erradoHXZ:727856180663287898> Eu não consigo apagar a sua ultima mensagem.')
    if (!time) return message.reply('<a:erradoHXZ:727856180663287898> Por favor especifique um tempo em segundos.')
    time = parseInt(time)
    if (!Number.isInteger(time)) return message.reply('<a:erradoHXZ:727856180663287898> Por favor especifique um tempo válido.')
    setTimeout(() => {
      if (target.deletable) target.delete()
    }, time * 1000)
    const sent = await message.reply(`Sua ultima mensagem será apagada em ${time} segundos.`)
    setTimeout(() => sent.delete(), 10000)
  },

  conf: {
    onlyguilds: true
  },

  help: {
    name: 'timer',
    usage: 'timer [segundos]'
  }
}